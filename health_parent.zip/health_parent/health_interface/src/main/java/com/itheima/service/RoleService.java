package com.itheima.service;

public interface RoleService {
}
