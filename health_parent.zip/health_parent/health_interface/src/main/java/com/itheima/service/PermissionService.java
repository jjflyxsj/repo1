package com.itheima.service;

public interface PermissionService {
}
